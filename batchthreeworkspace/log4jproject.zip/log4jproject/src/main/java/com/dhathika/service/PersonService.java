package com.dhathika.service;

import com.dhathika.model.Person;

public interface PersonService {
	
	public void savePerson(Person person);

}
