package com.dhathika.dao;

import com.dhathika.model.Person;

public interface PersonDao {
	
	public void savePerson(Person person);

}
