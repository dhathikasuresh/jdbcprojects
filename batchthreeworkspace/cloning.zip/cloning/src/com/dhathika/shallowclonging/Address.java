package com.dhathika.shallowclonging;

public class Address{
	
	int doorNo;
	String street;
	
	public Address(int doorNo, String street) {
		super();
		this.doorNo = doorNo;
		this.street = street;
	}
	
	

}
