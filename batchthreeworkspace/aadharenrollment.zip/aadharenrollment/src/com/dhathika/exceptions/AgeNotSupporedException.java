package com.dhathika.exceptions;

public class AgeNotSupporedException extends Exception {
 
   
   public AgeNotSupporedException(String message) {
	   super(message);
   }
}
